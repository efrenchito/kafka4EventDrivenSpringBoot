package com.appsdeveloperblog.ws.emailnotification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailNotificationMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
